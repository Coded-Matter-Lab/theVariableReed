import geomerative.*;
import controlP5.*;

ControlP5 cp5;
PImage plan = new PImage();
PImage output = new PImage();

ArrayList<WeaveShape> shapes = new ArrayList<WeaveShape>();

color[] clr = new color[6];
int[] pixOffset;

final int SHAPE_LONG_ROWS = 0;
final int SHAPE_ARC = 1;
final int SHAPE_TRIANGLE = 2;
final int SHAPE_TRAPEZOID = 3;
final int SHAPE_MOUNTAIN = 4;
final int SHAPE_VALLEY = 5;

final int PANEL_BG = 0xffd8d4cb;
final int PANEL_TEXT = 0xff2f2924;
final int PANEL_WIDTH = 275;
final int BUTTON_BG = 0xff8f9b8c;
final int BUTTON_ACTIVE_BG = 0xffc9544d;
final int BUTTON_HOVER_BG = 0xffa3afa0;
final int BUTTON_ACTIVE_HOVER_BG = 0xffa83f39;
final int BUTTON_FG = 0xfff7f4ee;
final int INPUT_BG = 0xfff2ede3;
final int INPUT_FG = 0xff2f2924;
final int INPUT_ACTIVE_BG = 0xffe4dbcb;
final int DENSITY_GROUP_BG = 0xffb7aea3;
final int GRID_BG = 125;
final int GRID_LINE = 140;

int heightCounter = 0;
int gridSnapSize = 10;
int heightLimit = 150;

int imagePosX = 300;
int imagePosY = 20;
int outputPosX = 830;
int planWidth = 500;
int planHeight = 500;

boolean drawArc = false;
boolean drawTriangle = false;
boolean longRows = false;
boolean showOutput = true;
boolean drawTrapzoid = false;
boolean editmode = false;
boolean drag = false;

int dragedIndex = -1;
RPoint[] controlPoints;
String activeButtonName = "";

float scaleFactorX = 1;
float scaleFactorY = 1;

void setup() {
  size(1550, 750);

  RG.init(this);
  RG.ignoreStyles(false);

  PFont pfont = createFont("Arial", 16, true);
  ControlFont font = new ControlFont(pfont, 13);

  plan = createImage(planWidth, planHeight, RGB);
  cp5 = new ControlP5(this);

  clr[SHAPE_LONG_ROWS] = color(230, 230, 200);
  clr[SHAPE_ARC] = color(123, 180, 10);
  clr[SHAPE_TRIANGLE] = color(255, 255, 0);
  clr[SHAPE_TRAPEZOID] = color(230, 121, 33);
  clr[SHAPE_MOUNTAIN] = color(255, 0, 0);
  clr[SHAPE_VALLEY] = color(0, 0, 255);

  pixOffset = new int[plan.width];

  Group densityGroup = cp5.addGroup("density")
    .setPosition(10, 36)
    .setWidth(PANEL_WIDTH - 20)
    .setBackgroundColor(DENSITY_GROUP_BG)
    .setBackgroundHeight(132)
    .setBarHeight(26)
    .setFont(font)
    .setLabel("Density Settings");

  densityGroup.getCaptionLabel().setColor(PANEL_TEXT);
  densityGroup.setColorBackground(DENSITY_GROUP_BG);
  densityGroup.setColorForeground(DENSITY_GROUP_BG);
  densityGroup.setColorActive(DENSITY_GROUP_BG);

  cp5.addTextlabel("labelEnds")
    .setText("Ends:")
    .setPosition(10, 15)
    .setFont(font)
    .moveTo(densityGroup);

  cp5.addTextfield("NumOfEnds")
    .setPosition(150, 10)
    .setSize(62, 22)
    .setAutoClear(false)
    .moveTo(densityGroup)
    .setLabel("")
    .setFont(font)
    .setValue("684")
    .setColorBackground(INPUT_BG)
    .setColor(color(INPUT_FG))
    .setColorActive(INPUT_ACTIVE_BG)
    .setColorForeground(INPUT_BG)
    .setColorCursor(INPUT_FG)
    .setColorCaptionLabel(PANEL_TEXT);

  cp5.addTextlabel("labelWarp")
    .setText("Warp Density:")
    .setFont(font)
    .setPosition(10, 55)
    .moveTo(densityGroup);

  cp5.addTextfield("warpDensity")
    .setPosition(150, 50)
    .setSize(42, 22)
    .setAutoClear(false)
    .setValue("18")
    .setFont(font)
    .moveTo(densityGroup)
    .setLabel("")
    .setColorBackground(INPUT_BG)
    .setColor(color(INPUT_FG))
    .setColorActive(INPUT_ACTIVE_BG)
    .setColorForeground(INPUT_BG)
    .setColorCursor(INPUT_FG)
    .setColorCaptionLabel(PANEL_TEXT);

  cp5.addTextlabel("labelWarp2")
    .setText("Ends / CM")
    .setFont(font)
    .setPosition(198, 55)
    .moveTo(densityGroup);

  cp5.addTextlabel("labelWeft")
    .setText("Weft Density:")
    .setFont(font)
    .setPosition(10, 95)
    .moveTo(densityGroup);

  cp5.addTextfield("weftDensity")
    .setPosition(150, 90)
    .setSize(42, 22)
    .setAutoClear(false)
    .setValue("6")
    .setFont(font)
    .moveTo(densityGroup)
    .setLabel("")
    .setColorBackground(INPUT_BG)
    .setColor(color(INPUT_FG))
    .setColorActive(INPUT_ACTIVE_BG)
    .setColorForeground(INPUT_BG)
    .setColorCursor(INPUT_FG)
    .setColorCaptionLabel(PANEL_TEXT);

  cp5.addTextlabel("labelweft2")
    .setText("Ends / CM")
    .setFont(font)
    .setPosition(198, 95)
    .moveTo(densityGroup);

  cp5.get(Textlabel.class, "labelEnds").setColorValue(PANEL_TEXT);
  cp5.get(Textlabel.class, "labelWarp").setColorValue(PANEL_TEXT);
  cp5.get(Textlabel.class, "labelWarp2").setColorValue(PANEL_TEXT);
  cp5.get(Textlabel.class, "labelWeft").setColorValue(PANEL_TEXT);
  cp5.get(Textlabel.class, "labelweft2").setColorValue(PANEL_TEXT);

  addStyledButton("AddArc", "Add Arc", 170, 30, font);
  addStyledButton("AddTrapazoid", "Add Trapezoid", 210, 30, font);
  addStyledButton("AddTriangle", "Add Triangle", 250, 30, font);
  addStyledButton("AddLongRows", "Add Curved Rows", 290, 30, font);
  addStyledButton("AddVally", "Add Valley", 330, 30, font);
  addStyledButton("AddMountain", "Add Mountain", 370, 30, font);
  addStyledButton("mirror", "Mirror Baked Pattern", 430, 30, font);

  cp5.addButton("expand")
    .setPosition(50, 480)
    .setLabel("Generate Draft")
    .setSize(120, 120)
    .setFont(font)
    .setColorBackground(color(95, 120, 100))
    .setColorForeground(color(110, 136, 115))
    .setColorActive(color(120, 148, 124))
    .setColorCaptionLabel(BUTTON_FG);

  cp5.addButton("reset")
    .setPosition(10, 615)
    .setSize(PANEL_WIDTH - 20, 50)
    .setFont(font)
    .setLabel("Reset")
    .setColorBackground(color(110, 109, 108))
    .setColorForeground(color(125, 123, 122))
    .setColorActive(color(140, 137, 133))
    .setColorCaptionLabel(BUTTON_FG);

  cp5.addButton("saveImage")
    .setPosition(10, 675)
    .setSize(PANEL_WIDTH - 20, 50)
    .setFont(font)
    .setLabel("Save Draft")
    .setColorBackground(color(110, 109, 108))
    .setColorForeground(color(125, 123, 122))
    .setColorActive(color(140, 137, 133))
    .setColorCaptionLabel(BUTTON_FG);

  drawGrid();
  updateButtonStates();
}

void draw() {
  scaleFactorX = getNumericValue("NumOfEnds", planWidth) / float(planWidth);
  scaleFactorY = getNumericValue("weftDensity", 6) / max(getNumericValue("warpDensity", 18), 0.001);

  background(190, 188, 182);

  noStroke();
  fill(PANEL_BG);
  rect(0, 0, PANEL_WIDTH, height);

  image(plan, imagePosX, imagePosY);
  drawCanvasFrame(imagePosX, imagePosY, planWidth, planHeight, "Canvas");

  int outputWidth = max(10, int(getNumericValue("NumOfEnds", planWidth)));
  fill(210, 207, 201);
  rect(outputPosX, imagePosY, outputWidth, 600);
  drawCanvasFrame(outputPosX, imagePosY, outputWidth, 600, "Draft Preview");

  if (showOutput) {
    drawOutputShapes();
  } else if (output != null && output.width > 0 && output.height > 0) {
    image(output, outputPosX, imagePosY);
  }

  drawPreviewShape();
  drawSidebarHelp();
}

void addStyledButton(String name, String label, int posY, int heightValue, ControlFont font) {
  cp5.addButton(name)
    .setLabel(label)
    .setPosition(10, posY)
    .setSize(PANEL_WIDTH - 20, heightValue)
    .setFont(font)
    .setColorBackground(BUTTON_BG)
    .setColorForeground(BUTTON_HOVER_BG)
    .setColorActive(color(182, 101, 92))
    .setColorCaptionLabel(BUTTON_FG);
}

void drawCanvasFrame(int x, int y, int w, int h, String label) {
  noFill();
  stroke(85, 80, 74);
  strokeWeight(1);
  rect(x, y, w, h);
  fill(PANEL_TEXT);
  textAlign(LEFT, BOTTOM);
  text(label, x, y - 6);
}

void drawOutputShapes() {
  noStroke();
  for (int i = 0; i < shapes.size(); i++) {
    fill(233);
    shapes.get(i).outputShape.draw();
  }
}

void drawPreviewShape() {
  if (!editmode || controlPoints == null) {
    return;
  }

  RShape previewShape = buildPreviewShape();
  if (previewShape != null) {
    fill(255, 255, 255, 140);
    stroke(80, 60, 55);
    previewShape.draw();
  }

  noStroke();
  for (int i = 0; i < controlPoints.length; i++) {
    if (dragedIndex == i && drag) {
      fill(255, 80, 80);
    } else {
      fill(246, 241, 232);
    }
    ellipse(controlPoints[i].x, controlPoints[i].y, 12, 12);
  }
}

void drawSidebarHelp() {
  fill(PANEL_TEXT);
  textAlign(LEFT, TOP);
  int instructionsX = imagePosX;
  int instructionsY = imagePosY + planHeight + 18;
  text("How to use:", instructionsX, instructionsY);
  text("1. Click a geometry button once to place a preview shape.", instructionsX, instructionsY + 20);
  text("2. Drag the control points to adjust the shape.", instructionsX, instructionsY + 38);
  text("3. Click the same red button again to bake it into the canvas.", instructionsX, instructionsY + 56);
  text("4. Use Mirror after baking to duplicate the pattern vertically.", instructionsX, instructionsY + 74);
  text("5. Click Generate Draft to build the output preview.", instructionsX, instructionsY + 92);
}

float getNumericValue(String fieldName, float fallbackValue) {
  String rawText = cp5.get(Textfield.class, fieldName).getText();
  if (rawText == null || rawText.length() == 0) {
    return fallbackValue;
  }
  rawText = trim(rawText);
  if (rawText.length() == 0) {
    return fallbackValue;
  }

  try {
    return float(rawText);
  } catch (RuntimeException ex) {
    return fallbackValue;
  }
}

void AddArc() {
  if (activeButtonName.equals("AddArc") && editmode) {
    bakeArcPreview();
    return;
  }

  cancelPreview();
  showOutput = true;
  drawArc = true;
  editmode = true;
  activeButtonName = "AddArc";

  int baseY = getDefaultPlanY(70);
  int centerX = imagePosX + planWidth / 2;
  controlPoints = new RPoint[3];
  controlPoints[0] = new RPoint(centerX - 80, baseY);
  controlPoints[1] = new RPoint(centerX, baseY + 70);
  controlPoints[2] = new RPoint(centerX + 80, baseY);
  updateButtonStates();
}

void AddTrapazoid() {
  if (activeButtonName.equals("AddTrapazoid") && editmode) {
    bakePolygonPreview(SHAPE_TRAPEZOID, 1);
    return;
  }

  cancelPreview();
  showOutput = true;
  drawTrapzoid = true;
  editmode = true;
  activeButtonName = "AddTrapazoid";

  int topY = getDefaultPlanY(40);
  int centerX = imagePosX + planWidth / 2;
  controlPoints = new RPoint[4];
  controlPoints[0] = new RPoint(centerX - 50, topY);
  controlPoints[1] = new RPoint(centerX + 50, topY);
  controlPoints[2] = new RPoint(centerX + 25, topY + 40);
  controlPoints[3] = new RPoint(centerX - 25, topY + 40);
  updateButtonStates();
}

void AddTriangle() {
  if (activeButtonName.equals("AddTriangle") && editmode) {
    bakePolygonPreview(SHAPE_TRIANGLE, 1);
    return;
  }

  cancelPreview();
  showOutput = true;
  drawTriangle = true;
  editmode = true;
  activeButtonName = "AddTriangle";

  int topY = getDefaultPlanY(40);
  int centerX = imagePosX + planWidth / 2;
  controlPoints = new RPoint[4];
  controlPoints[0] = new RPoint(centerX - 50, topY);
  controlPoints[1] = new RPoint(centerX + 50, topY);
  controlPoints[2] = new RPoint(centerX, topY + 40);
  controlPoints[3] = new RPoint(centerX, topY + 40);
  updateButtonStates();
}

void AddLongRows() {
  if (activeButtonName.equals("AddLongRows") && editmode) {
    bakeLongRowsPreview();
    return;
  }

  cancelPreview();
  showOutput = true;
  longRows = true;
  editmode = true;
  activeButtonName = "AddLongRows";

  int topY = getDefaultPlanY(40);
  int centerX = imagePosX + planWidth / 2;
  controlPoints = new RPoint[4];
  controlPoints[0] = new RPoint(centerX, topY);
  controlPoints[1] = new RPoint(centerX, topY + 40);
  controlPoints[2] = new RPoint(centerX, topY + 40);
  controlPoints[3] = new RPoint(centerX, topY);
  updateButtonStates();
}

void AddVally() {
  cancelPreview();
  addLongRowsBlock(2, 4, SHAPE_VALLEY);
}

void AddMountain() {
  cancelPreview();
  addLongRowsBlock(2, 4, SHAPE_MOUNTAIN);
}

void bakeArcPreview() {
  RShape previewShape = buildPreviewShape();
  if (previewShape != null) {
    bakePlanShape(previewShape, SHAPE_ARC, 1);
  }
  cancelPreview();
}

void bakePolygonPreview(int colorType, int outputType) {
  RShape previewShape = buildPreviewShape();
  if (previewShape != null) {
    bakePlanShape(previewShape, colorType, outputType);
  }
  cancelPreview();
}

void bakeLongRowsPreview() {
  if (controlPoints == null || controlPoints.length < 2) {
    cancelPreview();
    return;
  }

  int rowHeight = abs(int(controlPoints[1].y - controlPoints[0].y));
  rowHeight = max(gridSnapSize, rowHeight - (rowHeight % gridSnapSize));
  rowHeight = min(rowHeight, heightLimit);

  addLongRowsBlock(rowHeight, rowHeight, SHAPE_LONG_ROWS);
  cancelPreview();
}

void cancelPreview() {
  drawArc = false;
  drawTriangle = false;
  longRows = false;
  drawTrapzoid = false;
  editmode = false;
  drag = false;
  dragedIndex = -1;
  controlPoints = null;
  activeButtonName = "";
  updateButtonStates();
}

void updateButtonStates() {
  String[] geometryButtons = {
    "AddArc",
    "AddTrapazoid",
    "AddTriangle",
    "AddLongRows"
  };

  for (int i = 0; i < geometryButtons.length; i++) {
    boolean isActive = geometryButtons[i].equals(activeButtonName);
    Controller controller = cp5.getController(geometryButtons[i]);
    if (controller != null) {
      controller.setColorBackground(isActive ? BUTTON_ACTIVE_BG : BUTTON_BG);
      controller.setColorForeground(isActive ? BUTTON_ACTIVE_HOVER_BG : BUTTON_HOVER_BG);
    }
  }
}

int getDefaultPlanY(int previewHeight) {
  int y = imagePosY + getUsedPlanHeight();
  y = max(y, imagePosY);
  y = min(y, imagePosY + planHeight - previewHeight);
  return y;
}

RShape buildPreviewShape() {
  if (controlPoints == null) {
    return null;
  }

  if (drawArc && controlPoints.length == 3) {
    return buildArcShape(controlPoints[0], controlPoints[1], controlPoints[2]);
  }

  if (controlPoints.length >= 3) {
    return buildPolygonShape(controlPoints);
  }

  return null;
}

RShape buildPolygonShape(RPoint[] points) {
  if (points == null || points.length < 3) {
    return null;
  }

  RPoint[] copiedPoints = new RPoint[points.length];
  for (int i = 0; i < points.length; i++) {
    copiedPoints[i] = new RPoint(points[i].x, points[i].y);
  }

  RPath path = new RPath(copiedPoints);
  path.addClose();
  return new RShape(path);
}

RShape buildArcShape(RPoint startPoint, RPoint controlPoint, RPoint endPoint) {
  if (startPoint == null || controlPoint == null || endPoint == null) {
    return null;
  }

  RPoint leftPoint = startPoint;
  RPoint rightPoint = endPoint;

  if (startPoint.x > endPoint.x) {
    leftPoint = endPoint;
    rightPoint = startPoint;
  }

  int sampleCount = 24;
  RPoint[] arcPoints = new RPoint[sampleCount + 1];

  for (int i = 0; i <= sampleCount; i++) {
    float t = i / float(sampleCount);
    float oneMinusT = 1.0 - t;
    float x = oneMinusT * oneMinusT * leftPoint.x
      + 2 * oneMinusT * t * controlPoint.x
      + t * t * rightPoint.x;
    float y = oneMinusT * oneMinusT * leftPoint.y
      + 2 * oneMinusT * t * controlPoint.y
      + t * t * rightPoint.y;
    arcPoints[i] = new RPoint(x, y);
  }

  RPath path = new RPath(arcPoints);
  path.addClose();
  return new RShape(path);
}

void bakePlanShape(RShape planShape, int colorType, int outputType) {
  if (planShape == null) {
    return;
  }

  paintShapeOnPlan(planShape, colorType);
  shapes.add(new WeaveShape(cloneShape(planShape), buildOutputShape(planShape, outputType, -1), outputType, colorType, -1));
  refreshPixOffsets();
  showOutput = true;
}

RShape buildOutputShape(RShape planShape, int outputType, int forcedOutputHeight) {
  RShape outputShape = cloneShape(planShape);
  float shapePosX = planShape.getTopLeft().x - imagePosX;

  if (outputType == SHAPE_MOUNTAIN || outputType == SHAPE_VALLEY) {
    float targetHeight = forcedOutputHeight > 0 ? forcedOutputHeight : outputShape.getHeight();
    float scaleY = targetHeight / max(outputShape.getHeight(), 0.001);
    outputShape.scale(scaleFactorX, scaleY);
  } else {
    outputShape.scale(scaleFactorX, scaleFactorY);
  }

  outputShape.translate(-outputShape.getTopLeft().x, -outputShape.getTopLeft().y);
  outputShape.translate(outputPosX + shapePosX * scaleFactorX, imagePosY + heightCounter);
  heightCounter += int(ceil(outputShape.getHeight()));
  return outputShape;
}

RShape cloneShape(RShape sourceShape) {
  if (sourceShape == null) {
    return null;
  }
  return buildPolygonShape(sourceShape.getPoints());
}

void paintShapeOnPlan(RShape shapeToBake, int shapeType) {
  plan.loadPixels();
  for (int j = 0; j < plan.width; j++) {
    for (int i = 0; i < plan.height; i++) {
      if (shapeToBake.contains(new RPoint(j + imagePosX, i + imagePosY))) {
        plan.pixels[i * plan.width + j] = clr[shapeType];
      }
    }
  }
  plan.updatePixels();
}

void addLongRowsBlock(int planRows, int outputRows, int type) {
  int constrainedPlanRows = planRows;
  if (type == SHAPE_LONG_ROWS) {
    constrainedPlanRows = constrain(planRows, gridSnapSize, heightLimit);
  } else {
    constrainedPlanRows = constrain(planRows, 1, heightLimit);
  }

  outputRows = constrain(outputRows, 1, heightLimit);
  if (constrainedPlanRows <= 0 || outputRows <= 0) {
    return;
  }

  int blockTop = getUsedPlanHeight();
  blockTop = min(blockTop, plan.height - constrainedPlanRows);

  plan.loadPixels();
  for (int j = 0; j < plan.width; j++) {
    int patternHeight = blockTop;
    for (int i = 0; i < plan.height - constrainedPlanRows; i++) {
      color currPixel = plan.pixels[i * plan.width + j];
      color nextPixel = plan.pixels[(i + 1) * plan.width + j];
      if (isBakedColor(currPixel) && isGridColor(nextPixel)) {
        patternHeight = i + 1;
      }
    }

    for (int k = 0; k < constrainedPlanRows && patternHeight + k < plan.height; k++) {
      plan.pixels[(patternHeight + k) * plan.width + j] = clr[type];
    }
  }
  plan.updatePixels();

  RPoint[] blockPoints = new RPoint[4];
  blockPoints[0] = new RPoint(imagePosX, imagePosY + blockTop);
  blockPoints[1] = new RPoint(imagePosX + plan.width, imagePosY + blockTop);
  blockPoints[2] = new RPoint(imagePosX + plan.width, imagePosY + blockTop + constrainedPlanRows);
  blockPoints[3] = new RPoint(imagePosX, imagePosY + blockTop + constrainedPlanRows);

  RShape planShape = buildPolygonShape(blockPoints);
  shapes.add(new WeaveShape(planShape, buildOutputShape(planShape, type, outputRows), type, type, outputRows));
  refreshPixOffsets();
  showOutput = true;
}

boolean isGridColor(color testColor) {
  return testColor == color(GRID_BG) || testColor == color(GRID_LINE);
}

boolean isBakedColor(color testColor) {
  for (int i = 0; i < clr.length; i++) {
    if (testColor == clr[i]) {
      return true;
    }
  }
  return false;
}

int getUsedPlanHeight() {
  plan.loadPixels();
  int usedHeight = 0;
  for (int i = 0; i < plan.height; i++) {
    for (int j = 0; j < plan.width; j++) {
      if (isBakedColor(plan.pixels[i * plan.width + j])) {
        usedHeight = max(usedHeight, i + 1);
      }
    }
  }
  return usedHeight;
}

void refreshPixOffsets() {
  for (int j = 0; j < plan.width; j++) {
    pixOffset[j] = 0;
  }

  plan.loadPixels();
  for (int j = 0; j < plan.width; j++) {
    for (int i = 0; i < plan.height; i++) {
      if (isBakedColor(plan.pixels[i * plan.width + j])) {
        pixOffset[j] = i + 1;
      }
    }
  }
}

void expand() {
  showOutput = false;
  output = createImage(max(1, int(plan.width * scaleFactorX)), max(1, heightCounter), RGB);
  output.loadPixels();

  for (int i = 0; i < output.pixels.length; i++) {
    output.pixels[i] = color(255);
  }

  int sampleGridSize = 4;

  for (int k = 0; k < shapes.size(); k++) {
    RShape currShape = shapes.get(k).outputShape;
    int shapeType = shapes.get(k).type;

    for (int i = 0; i < output.height / sampleGridSize; i++) {
      int offset = 0;
      for (int j = 0; j < output.width / sampleGridSize; j++) {
        int currPixX = j * sampleGridSize + outputPosX;
        int currPixY = i * sampleGridSize + imagePosY;

        if (currShape.contains(new RPoint(currPixX, currPixY))) {
          for (int p = 0; p < sampleGridSize; p++) {
            offset++;
            for (int m = 0; m < sampleGridSize; m++) {
              color pixelColor = color(255);

              switch (shapeType) {
              case SHAPE_LONG_ROWS:
              case SHAPE_ARC:
                if ((i + p + (i % 2)) % 2 == 0 && (j + m + (j % 2)) % 2 == 0) {
                  pixelColor = color(0);
                }
                if ((i + p + (i % 2)) % 2 == 1 && (j + m + (j % 2)) % 2 == 1) {
                  pixelColor = color(255, 0, 0);
                }
                break;
              case SHAPE_MOUNTAIN:
                if ((m + offset + i % 2) % 4 == 0) {
                  pixelColor = color(255, 0, 0);
                }
                break;
              case SHAPE_VALLEY:
                if ((m + offset + i % 2) % 4 < 3) {
                  pixelColor = color(255, 0, 0);
                }
                break;
              }

              output.pixels[(i * sampleGridSize + p) * output.width + (j * sampleGridSize + m)] = pixelColor;
            }
          }
        }
      }
    }
  }

  output.updatePixels();
}

void mirror() {
  cancelPreview();

  int usedHeight = getUsedPlanHeight();
  if (usedHeight <= 0) {
    return;
  }

  if (usedHeight * 2 > planHeight) {
    println("Mirror skipped: not enough vertical room on the canvas.");
    return;
  }

  plan.loadPixels();
  color[] originalPixels = new color[plan.pixels.length];
  arrayCopy(plan.pixels, originalPixels);

  for (int y = 0; y < usedHeight; y++) {
    int targetY = (usedHeight * 2 - 1) - y;
    for (int x = 0; x < plan.width; x++) {
      color sourceColor = originalPixels[y * plan.width + x];
      if (isBakedColor(sourceColor)) {
        plan.pixels[targetY * plan.width + x] = sourceColor;
      }
    }
  }
  plan.updatePixels();

  int originalShapeCount = shapes.size();
  float axisY = imagePosY + usedHeight - 0.5;
  for (int i = 0; i < originalShapeCount; i++) {
    WeaveShape originalShape = shapes.get(i);
    RShape mirroredPlanShape = mirrorShapeVertically(originalShape.planShape, axisY);
    shapes.add(new WeaveShape(mirroredPlanShape, buildOutputShape(mirroredPlanShape, originalShape.type, originalShape.outputHeight), originalShape.type, originalShape.colorType, originalShape.outputHeight));
  }

  refreshPixOffsets();
  showOutput = true;
}

RShape mirrorShapeVertically(RShape sourceShape, float axisY) {
  RPoint[] sourcePoints = sourceShape.getPoints();
  RPoint[] mirroredPoints = new RPoint[sourcePoints.length];

  for (int i = 0; i < sourcePoints.length; i++) {
    float mirroredY = axisY + (axisY - sourcePoints[i].y);
    mirroredPoints[i] = new RPoint(sourcePoints[i].x, mirroredY);
  }

  return buildPolygonShape(mirroredPoints);
}

void reset() {
  drawGrid();
  for (int j = 0; j < plan.width; j++) {
    pixOffset[j] = 0;
  }
  shapes.clear();
  heightCounter = 0;
  showOutput = true;
  output = new PImage();
  cancelPreview();
}

void drawGrid() {
  plan.loadPixels();
  for (int i = 0; i < plan.height; i++) {
    for (int j = 0; j < plan.width; j++) {
      color c = color(GRID_BG);
      if (i % gridSnapSize == 0 || j % gridSnapSize == 0) {
        c = color(GRID_LINE);
      }
      plan.pixels[i * plan.width + j] = c;
    }
  }
  plan.updatePixels();
}

void saveImage() {
  if (output != null && output.width > 0 && output.height > 0) {
    selectOutput("Save as..", "saveFileSelected");
  }
}

void saveFileSelected(File selection) {
  noLoop();
  if (selection != null) {
    output.save(selection.toString());
  }
  loop();
}
