int checkOutofBounds(int val, String checkWhat) {
  if ("horizontal".equals(checkWhat)) {
    if (val < imagePosX) {
      val = imagePosX;
    }
    if (val > imagePosX + planWidth) {
      val = imagePosX + planWidth;
    }
  }

  if ("vertical".equals(checkWhat)) {
    if (val < imagePosY) {
      val = imagePosY;
    }
    if (val > imagePosY + planHeight) {
      val = imagePosY + planHeight;
    }
  }

  return val;
}

int snapHorizontal(int value) {
  return checkOutofBounds(value - (value % gridSnapSize), "horizontal");
}

int snapVertical(int value) {
  return checkOutofBounds(value - (value % gridSnapSize), "vertical");
}
