class WeaveShape {
  RShape planShape;
  RShape outputShape;
  int type;
  int colorType;
  int outputHeight;

  WeaveShape(RShape planShapeValue, RShape outputShapeValue, int shapeType, int planColorType, int outputHeightValue) {
    planShape = planShapeValue;
    outputShape = outputShapeValue;
    type = shapeType;
    colorType = planColorType;
    outputHeight = outputHeightValue;
  }
}
