void mousePressed() {
  if (!editmode || controlPoints == null) {
    return;
  }

  drag = false;
  dragedIndex = -1;
  for (int i = 0; i < controlPoints.length; i++) {
    if (dist(mouseX, mouseY, controlPoints[i].x, controlPoints[i].y) < 10) {
      drag = true;
      dragedIndex = i;
      return;
    }
  }
}

void mouseDragged() {
  if (!editmode || !drag || dragedIndex < 0 || controlPoints == null) {
    return;
  }

  if (drawTrapzoid) {
    dragTrapazoidControlPoint();
    return;
  }

  if (drawTriangle) {
    dragTriangleControlPoint();
    return;
  }

  if (drawArc) {
    dragArcControlPoint();
    return;
  }

  if (longRows) {
    dragLongRowsControlPoint();
  }
}

void mouseReleased() {
  drag = false;
  dragedIndex = -1;
}

void dragTrapazoidControlPoint() {
  int snappedX = snapHorizontal(mouseX);
  int snappedY = snapVertical(mouseY);

  controlPoints[dragedIndex].x = snappedX;
  if (dragedIndex > 1) {
    controlPoints[2].y = snappedY;
    controlPoints[3].y = snappedY;
  } else {
    controlPoints[0].y = snappedY;
    controlPoints[1].y = snappedY;
  }
}

void dragTriangleControlPoint() {
  int snappedX = snapHorizontal(mouseX);
  int snappedY = snapVertical(mouseY);

  if (dragedIndex < 2) {
    controlPoints[dragedIndex].x = snappedX;
    controlPoints[0].y = snappedY;
    controlPoints[1].y = snappedY;
  } else {
    controlPoints[2].x = snappedX;
    controlPoints[2].y = snappedY;
    controlPoints[3] = new RPoint(controlPoints[2].x, controlPoints[2].y);
  }
}

void dragArcControlPoint() {
  controlPoints[dragedIndex].x = snapHorizontal(mouseX);
  controlPoints[dragedIndex].y = snapVertical(mouseY);
}

void dragLongRowsControlPoint() {
  int snappedY = snapVertical(mouseY);
  controlPoints[1].y = snappedY;
  controlPoints[2].y = snappedY;
}
